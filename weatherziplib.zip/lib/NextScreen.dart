import 'package:flutter/material.dart';
import 'repo.dart';
import 'weather_model.dart';

class NextScreen extends StatefulWidget {
  final String initialLocation;

  const NextScreen({Key? key, required this.initialLocation}) : super(key: key);

  @override
  State<NextScreen> createState() => _NextScreenState();
}

class _NextScreenState extends State<NextScreen> {
  TextEditingController controller = TextEditingController();
  WeatherModel? weatherModel;

  @override
  void initState() {
    super.initState();
    controller.text = widget.initialLocation;
    _fetchWeather(widget.initialLocation);
  }

  Future<void> _fetchWeather(String city) async {
    WeatherModel? weather = await Repo().getWeather(city);
    setState(() {
      weatherModel = weather;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Weather App"),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Enter city name',
                  style: TextStyle(fontSize: 20),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: controller,
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                    hintText: 'e.g. London',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(
                    height:
                        16.0), // Adding some space between TextField and Button
                ElevatedButton(
                  onPressed: () async {
                    String city = controller.text;
                    await _fetchWeather(city);
                  },
                  child: Text("Search"),
                ),
                SizedBox(
                    height:
                        16.0), // Adding some space between Button and Weather info
                if (weatherModel != null)
                  Column(
                    children: [
                      Text("Temperature: ${weatherModel?.main?.temp}"),
                      Text("Feels Like: ${weatherModel?.main?.feelsLike}"),
                      Text(
                          "Minimum Temperature: ${weatherModel?.main?.tempMin}"),
                      Text(
                          "Maximum Temperature: ${weatherModel?.main?.tempMax}"),
                      Text("Pressure: ${weatherModel?.main?.pressure}"),
                      Text("Humidity: ${weatherModel?.main?.humidity}"),
                      Text("Wind Gust: ${weatherModel?.wind?.gust}"),
                      Text("Wind Speed: ${weatherModel?.wind?.speed}"),
                      Text("Wind Degree: ${weatherModel?.wind?.deg}"),
                      Text("Sunrise Time: ${weatherModel?.sys?.sunrise}"),
                      Text("Sunset Time: ${weatherModel?.sys?.sunset}"),
                    ],
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
